import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JList;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Home extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Home frame = new Home();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Home() {
		// Pozitionare frame
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1366, 768);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		// Creare panel principal
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 51, 255));
		panel.setBounds(0, 0, 1362, 768);
		contentPane.add(panel);
		panel.setLayout(null);
		// Label pentru " WELCOME"
		JLabel lblNewLabel = new JLabel("Welcome!");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 90));
		lblNewLabel.setBounds(493, 301, 449, 92);
		panel.add(lblNewLabel);
		
		
		JMenuItem mntmNewMenuItem = new JMenuItem("New Member");
		mntmNewMenuItem.setForeground(new Color(255, 255, 255));
		mntmNewMenuItem.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new NewMember().setVisible(true); //Cand apasam butonul "New Member" se deschide frame-ul corespunzator
				
			}
		});
		// Personalizare buton
		mntmNewMenuItem.setBackground(new Color(0, 51, 255));
		mntmNewMenuItem.setFont(new Font("Tahoma", Font.BOLD, 17));
		mntmNewMenuItem.setIcon(new ImageIcon(Home.class.getResource("/Images/new member.png")));
		mntmNewMenuItem.setBounds(10, 10, 192, 64);
		panel.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("Update & delete member");
		mntmNewMenuItem_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new UpdateDeleteMember().setVisible(true); //Cand apasam butonul "Update & delete member" se deschide frame-ul corespunzator
			}
		});
		// Personalizare buton
		mntmNewMenuItem_1.setForeground(new Color(255, 255, 255));
		mntmNewMenuItem_1.setBackground(new Color(0, 51, 255));
		mntmNewMenuItem_1.setFont(new Font("Tahoma", Font.BOLD, 17));
		mntmNewMenuItem_1.setIcon(new ImageIcon(Home.class.getResource("/Images/update & delete member.png")));
		mntmNewMenuItem_1.setBounds(212, 10, 303, 70);
		panel.add(mntmNewMenuItem_1);
		
		JMenuItem mntmListOfMembers = new JMenuItem("List of Members");
		mntmListOfMembers.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new ListOfMembers().setVisible(true); //Cand apasam butonul "List of Members" se deschide frame-ul corespunzator
				
			}
		});
		// Personalizare buton
		mntmListOfMembers.setForeground(new Color(255, 255, 255));
		mntmListOfMembers.setBackground(new Color(0, 51, 255));
		mntmListOfMembers.setIcon(new ImageIcon(Home.class.getResource("/Images/list of members.png")));
		mntmListOfMembers.setFont(new Font("Tahoma", Font.BOLD, 17));
		mntmListOfMembers.setBounds(519, 10, 231, 64);
		panel.add(mntmListOfMembers);
		
		JMenuItem mntmPayment = new JMenuItem("Payment");
		mntmPayment.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new Payment().setVisible(true); //Cand apasam butonul "Payment" se deschide frame-ul corespunzator
				
				
			}
		});
		// Personalizare buton
		mntmPayment.setForeground(new Color(255, 255, 255));
		mntmPayment.setBackground(new Color(0, 51, 255));
		mntmPayment.setIcon(new ImageIcon(Home.class.getResource("/Images/payment.png")));
		mntmPayment.setFont(new Font("Tahoma", Font.BOLD, 17));
		mntmPayment.setBounds(747, 10, 166, 64);
		panel.add(mntmPayment);
		
		JMenuItem mntmLogOut = new JMenuItem("Log out");
		mntmLogOut.setForeground(new Color(255, 255, 255));
		mntmLogOut.setBackground(new Color(0, 51, 255));
		mntmLogOut.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int a = JOptionPane.showConfirmDialog(null,"Do you really want to log out?","Select",JOptionPane.YES_NO_OPTION); // Verificam daca utilizatorul e sigur
				if(a==0)
				{
					setVisible(false); // Facem invizibila fereastra principala
					new login().setVisible(true); // Facem vizibila fereastra de login
				}
			}
		});
		mntmLogOut.setIcon(new ImageIcon(Home.class.getResource("/Images/logout.png")));
		mntmLogOut.setFont(new Font("Tahoma", Font.BOLD, 17));
		mntmLogOut.setBounds(923, 10, 166, 64);
		panel.add(mntmLogOut);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mntmExit.setForeground(new Color(255, 255, 255));
		mntmExit.setBackground(new Color(0, 51, 255));
		mntmExit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int a = JOptionPane.showConfirmDialog(null,"Do you really want to exit?","Select",JOptionPane.YES_NO_OPTION);
				if(a==0)
				{
					System.exit(0); // Cand apasam butonul "Exit" se va inchide aplicatia
				}
			}
		});
		mntmExit.setIcon(new ImageIcon(Home.class.getResource("/Images/exit.png")));
		mntmExit.setFont(new Font("Tahoma", Font.BOLD, 17));
		mntmExit.setBounds(1099, 10, 146, 64);
		panel.add(mntmExit);
	}
}
