import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Font;
import javax.swing.ButtonGroup;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JCheckBox;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

public class login extends JFrame {

	private JPanel contentPane;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JPasswordField jEnterPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public login() {
		setUndecorated(true); 
		// Pozitionam frame-ul principal
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1366, 768);
		// cream un nou panel in care sa putem lucra
		contentPane = new JPanel();
		contentPane.setForeground(new Color(0, 51, 255));
		contentPane.setBackground(new Color(255, 250, 240));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null); // layout absolute
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int a = JOptionPane.showConfirmDialog(null,"Do you really want to exit application ?","Select", JOptionPane.YES_NO_OPTION );
				if(a==0) {
					System.exit(0); // Cand apasam butonul "Exit" se va inchide frame-ul
				}
			}
		});
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(255, 250, 240));
		btnNewButton.setIcon(new ImageIcon(login.class.getResource("/Images/close.png")));
		btnNewButton.setBounds(400, 192, 38, 38);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("LOG IN");
		lblNewLabel.setForeground(new Color(0, 51, 255));
		lblNewLabel.setBackground(new Color(255, 250, 240));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 48));
		lblNewLabel.setBounds(733, 192, 186, 92);
		contentPane.add(lblNewLabel);
		// Setam un label in cazul in care se introduc date incorecte
		JLabel lblNewLabel_1 = new JLabel("Incorrect Username or Password");
		lblNewLabel_1.setBackground(new Color(255, 250, 240));
		lblNewLabel_1.setIcon(new ImageIcon(login.class.getResource("/Images/close.png")));
		lblNewLabel_1.setForeground(new Color(255, 51, 0));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(695, 294, 281, 38);
		contentPane.add(lblNewLabel_1);
		lblNewLabel_1.setVisible(false); // Initial, mesajul "Incorrect Username or Password" nu este vizibil
		jEnterPassword = new JPasswordField("Enter Password");
		jEnterPassword.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				lblNewLabel_1.setVisible(false);
				if(jEnterPassword.getText().equals("Enter Password")) {
					jEnterPassword.setText(""); // Cand utilizatorul apasa pe label, se sterge textul "Enter Password"
					jEnterPassword.setForeground(new Color(0,188,221));
					
				}
			}
			@Override
			public void focusLost(FocusEvent e) { // Daca utilizatorul retrage cursorul din label
				lblNewLabel_1.setVisible(false);
				if(jEnterPassword.getText().equals("")) {    // Daca utilizatorul nu introduce valori
					jEnterPassword.setText("Enter Password");  // Se rescrie textul "Enter Password"
					jEnterPassword.setForeground(new Color(0,188,221));
					
				}
			}
		});
		jEnterPassword.setForeground(new Color(0, 51, 255));
		jEnterPassword.setBackground(new Color(255, 250, 240));
		jEnterPassword.setToolTipText("");
		jEnterPassword.setFont(new Font("Tahoma", Font.BOLD, 14));
		jEnterPassword.setBounds(695, 378, 281, 23);
		contentPane.add(jEnterPassword);
		
		JTextArea jEnterUsername = new JTextArea();
		jEnterUsername.addFocusListener(new FocusAdapter() {
			@Override
			public void focusGained(FocusEvent e) {
				lblNewLabel_1.setVisible(false); //  Initial, mesajul "Incorrect Username or Password" nu este vizibil
				if(jEnterUsername.getText().equals("Enter Username")) { 
					jEnterUsername.setText("");           // La fel ca la password
					jEnterUsername.setForeground(new Color(0,188,221));
					
				}
			}
			@Override
			public void focusLost(FocusEvent e) {
				lblNewLabel_1.setVisible(false);
				if(jEnterUsername.getText().equals("")) {
					jEnterUsername.setText("Enter Username"); // La fel ca la password
					jEnterUsername.setForeground(new Color(0,188,221));
					
				}
			}
		});
		jEnterUsername.setForeground(new Color(0, 51, 255));
		jEnterUsername.setBackground(new Color(255, 250, 240));
		jEnterUsername.setFont(new Font("Monospaced", Font.BOLD, 14));
		jEnterUsername.setText("Enter Username");
		jEnterUsername.setBounds(695, 346, 281, 22);
		contentPane.add(jEnterUsername);
		
		JButton btnNewButton_1 = new JButton("Log in");
		btnNewButton_1.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton_1.setForeground(new Color(0, 51, 255));
		btnNewButton_1.setBackground(new Color(255, 250, 240));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(jEnterUsername.getText().equals("admin") && jEnterPassword.getText().equals("123456789")) // verificam daca datele introduse sunt corecte
				{
					setVisible(false); // facem invizibila fereastra de login
					new Home().setVisible(true); // deschidem fereastra principala
				}
				else lblNewLabel_1.setVisible(true); // Altfel se va afisa textul "Incorrect Username or Password"
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1.setIcon(new ImageIcon(login.class.getResource("/Images/login.png")));
		btnNewButton_1.setBounds(697, 466, 116, 21);
		contentPane.add(btnNewButton_1);
		
		JCheckBox jCheckBox = new JCheckBox("Show Password"); // Facem un checkbox pentru afisarea parolei
		jCheckBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				if(jCheckBox.isSelected()){
					jEnterPassword.setEchoChar((char)0); // Asa afisam parola
				}
				else {
					jEnterPassword.setEchoChar('*'); // Daca nu e selectat, se afiseaza cu stelute
				}
			}
		});
		jCheckBox.setForeground(new Color(0, 51, 255));
		jCheckBox.setBackground(new Color(255, 250, 240));
		jCheckBox.setFont(new Font("Tahoma", Font.BOLD, 14));
		jCheckBox.setBounds(888, 466, 139, 21);
		contentPane.add(jCheckBox);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setIcon(new ImageIcon(login.class.getResource("/Images/login background.PNG")));
		lblNewLabel_2.setBounds(0, 0, 1352, 751);
		contentPane.add(lblNewLabel_2);
	}
}
