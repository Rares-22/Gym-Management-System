import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.DefaultComboBoxModel;
import project.connectionProvider;
import java.sql.*;
import java.awt.Point;



public class NewMember extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewMember frame = new NewMember();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NewMember() {
		setUndecorated(true);
		// Setarea frame-ului principal
		setLocation(new Point(175, 1000));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(0, 0, 0));
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 1000, 600);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false); // Cand apasam butonul "Exit" se va inchide frame-ul
			}
		});
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setIcon(new ImageIcon(NewMember.class.getResource("/Images/close.png")));
		btnNewButton.setBounds(10, 10, 31, 21);
		panel.add(btnNewButton);
		// Setam un titlu
		JLabel lblNewLabel = new JLabel("New Member");
		lblNewLabel.setForeground(new Color(0, 51, 255));
		lblNewLabel.setBackground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 48));
		lblNewLabel.setIcon(new ImageIcon(NewMember.class.getResource("/Images/new member.png")));
		lblNewLabel.setBounds(575, 10, 403, 65);
		panel.add(lblNewLabel);
		
		// Label-uri si text field-uri pentru introducerea datelor
		JLabel lblNewLabel_1 = new JLabel("Member ID: ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(10, 101, 94, 13);
		panel.add(lblNewLabel_1);
		
		JLabel jLabelID = new JLabel("00");
		jLabelID.setForeground(new Color(0, 51, 255));
		jLabelID.setFont(new Font("Tahoma", Font.BOLD, 14));
		jLabelID.setBounds(114, 101, 70, 13);
		panel.add(jLabelID);
		
		JLabel lblNewLabel_3 = new JLabel("Name: ");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_3.setBounds(10, 131, 70, 13);
		panel.add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField.setBounds(10, 154, 369, 19);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Mobile Number: ");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_4.setBounds(10, 205, 125, 13);
		panel.add(lblNewLabel_4);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField_1.setBounds(10, 228, 369, 19);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("E-mail");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_5.setBounds(10, 278, 70, 13);
		panel.add(lblNewLabel_5);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField_2.setBounds(10, 301, 369, 19);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Gender");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_6.setBounds(10, 359, 99, 13);
		panel.add(lblNewLabel_6);
		
		JComboBox comboBox = new JComboBox(); // ComboBox pentru selectarea unei optiuni
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Male", "Female"}));
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 14));
		comboBox.setMaximumRowCount(2);
		comboBox.setBounds(10, 380, 369, 21);
		panel.add(comboBox);
		
		JLabel lblNewLabel_7 = new JLabel("Father Name");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_7.setBounds(10, 437, 99, 13);
		panel.add(lblNewLabel_7);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField_3.setBounds(10, 460, 369, 19);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Save"); // Buton de SAVE
		btnNewButton_1.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton_1.setIcon(new ImageIcon(NewMember.class.getResource("/Images/save.png")));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1.setBounds(10, 520, 94, 21);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Reset"); // Buton de RESET
		btnNewButton_2.setIcon(new ImageIcon(NewMember.class.getResource("/Images/reset.png")));
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new NewMember().setVisible(true); // La apasarea butonului, deschidem un frame nou cu campuri necompletate
				
			}
		});
		btnNewButton_2.setBounds(272, 520, 107, 21);
		panel.add(btnNewButton_2);
		
		JLabel lblNewLabel_8 = new JLabel("Mother Name");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_8.setBounds(555, 133, 115, 13);
		panel.add(lblNewLabel_8);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField_4.setBounds(555, 156, 369, 19);
		panel.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("Gym Time");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_9.setBounds(565, 194, 94, 35);
		panel.add(lblNewLabel_9);
		
		JComboBox comboBox1 = new JComboBox(); // ComboBox pentru selectarea unei optiuni
		comboBox1.setModel(new DefaultComboBoxModel(new String[] {"06:00 - 14:00", "14:00 - 23:00", "FULL"}));
		comboBox1.setFont(new Font("Tahoma", Font.BOLD, 14));
		comboBox1.setBounds(555, 229, 369, 21);
		panel.add(comboBox1);
		
		JLabel lblNewLabel_10 = new JLabel("Age");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_10.setBounds(555, 272, 61, 24);
		panel.add(lblNewLabel_10);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField_5.setBounds(555, 301, 369, 19);
		panel.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblNewLabel_11 = new JLabel("Amount to pay/month");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_11.setBounds(556, 355, 174, 21);
		panel.add(lblNewLabel_11);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField_6.setBounds(555, 383, 369, 19);
		panel.add(textField_6);
		textField_6.setColumns(10);
		
		
		btnNewButton_1.addActionListener(new ActionListener() { // La apasarea butonului SAVE
			public void actionPerformed(ActionEvent e) {
				// Declaram valori pentru a retine datele
				String id = jLabelID.getText();
				String nume = textField.getText();
				String mobilenumber = textField_1.getText();
				String email = textField_2.getText();
				String gender = (String)comboBox.getSelectedItem();
				String fathername = textField_3.getText();
				String mothername = textField_4.getText();
				String gymtime = (String)comboBox1.getSelectedItem();
				String age = textField_5.getText();
				String amount = textField_6.getText();
				
				try {
					// Adaugam valorile in tabel
					Connection c = connectionProvider.getConnection();
					PreparedStatement ps = c.prepareStatement("insert into membrii values(?,?,?,?,?,?,?,?,?,?)");
					ps.setString(1,id);
					ps.setString(2,nume);
					ps.setString(3,mobilenumber);
					ps.setString(4,email);
					ps.setString(5,gender);
					ps.setString(6,fathername);
					ps.setString(7,mothername);
					ps.setString(8,gymtime);
					ps.setString(9,age);
					ps.setString(10,amount);
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Successfully saved!");
					setVisible(false);
					new NewMember().setVisible(true); // Facem vizibila o noua fereastra cu campuri necompletate
					
				}catch(Exception p) {
					JOptionPane.showMessageDialog(null,p);
				}
				
			}
		});
		
		try 
		{
			int id=1;
			String str1 = String.valueOf(id);
			jLabelID.setText(str1);
			Connection c = connectionProvider.getConnection();
			Statement st = c.createStatement();
			ResultSet rs = st.executeQuery("select max(id) from membrii"); // Cautam id-ul ultimului membru adaugat
			while(rs.next())
			{
				id=rs.getInt(1);
				id=id+1; // Il incrementam cu 1, pentru adaugarea urmatorului client
				String str = String.valueOf(id);
				jLabelID.setText(str);
			}
			
		} catch(Exception e){
			JOptionPane.showMessageDialog(null,e);
		}
	}
}
