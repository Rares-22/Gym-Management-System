import java.awt.BorderLayout;
import java.sql.*;
import project.connectionProvider;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Point;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ListOfMembers extends JFrame {

	private JPanel contentPane;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ListOfMembers frame = new ListOfMembers();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ListOfMembers() {
		setUndecorated(true);
		//Setam locatia frame-ului
		setLocation(new Point(175, 100));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setForeground(new Color(0, 51, 255));
		panel.setBounds(0, 0, 1000, 600);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false); // La apasarea butonului "Exit", frame-ul se va inchide
			}
		});
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setIcon(new ImageIcon(ListOfMembers.class.getResource("/Images/close.png")));
		btnNewButton.setBounds(10, 10, 26, 21);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("List of Members");
		lblNewLabel.setForeground(new Color(0, 51, 255));
		lblNewLabel.setIcon(new ImageIcon(ListOfMembers.class.getResource("/Images/list of members.png")));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 48));
		lblNewLabel.setBounds(282, 10, 469, 58);
		panel.add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane(); // Am adaugat un scrollpane pentru tabel
		scrollPane.setBounds(10, 198, 980, 166);
		panel.add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel( // Initializam tabelul cu coloanele principale
			new Object[][] {
			},
			new String[] {
				"ID", "Name", "Mobile Number", "E-mail", "Gender", "Father Name", "Mother Name", "Gym Time", "Age", "Amount"}
			) 
			{
			Class[] columnTypes = new Class[] { // Setam tipul coloanelor
				Integer.class, String.class, String.class, String.class, String.class, String.class, String.class, String.class, Integer.class, Integer.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		scrollPane.setViewportView(table); //Stabilim locatia tabelului in scrollpane
		DefaultTableModel model = (DefaultTableModel)table.getModel();
		try {
			Connection c = connectionProvider.getConnection();
			Statement st = c.createStatement();
			ResultSet rs = st.executeQuery("Select* from membrii ");
			
			while(rs.next())
			{   // introducem datele membriilor in tabel
				model.addRow(new Object[] {rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10)});

				
			}
		
		}catch(Exception t) {
	     JOptionPane.showMessageDialog(null,t);
		}
	}
}
