import java.awt.BorderLayout;
import project.connectionProvider;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.SwingConstants;
import java.awt.Point;
public class UpdateDeleteMember extends JFrame {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_7;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UpdateDeleteMember frame = new UpdateDeleteMember();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UpdateDeleteMember() {
		setUndecorated(true);
		// Setam frame-ul principal
		setLocation(new Point(175, 100));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1000, 600);
		JPanel contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		// Generam un panel in care sa adaugam elementele
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 1000, 600);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false); // La apasarea butonului "Exit", frame-ul se va inchide
			}
		});
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setIcon(new ImageIcon(UpdateDeleteMember.class.getResource("/Images/close.png")));
		btnNewButton.setBounds(10, 10, 24, 21);
		panel.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Update / Delete Member");
		lblNewLabel.setForeground(new Color(0, 51, 255));
		lblNewLabel.setIcon(new ImageIcon(UpdateDeleteMember.class.getResource("/Images/update & delete member.png")));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 48));
		lblNewLabel.setBounds(224, 23, 670, 65);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Member ID: ");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(10, 139, 108, 13);
		panel.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField.setBounds(111, 136, 86, 19);
		panel.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Search");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { // La apasarea butonului SEARCH
				
				int check = 0;
				String id = textField.getText(); // Retinem id-ul introdus
				try {
					Connection c = connectionProvider.getConnection();
					Statement st = c.createStatement();
					ResultSet rs = st.executeQuery("Select* from membrii where id='"+id+"'"); // Alegem membrul cu id-ul cautat
					
					while(rs.next())
					{	// Obtinem datele membrului
						check=1;
						textField.setEditable(false); // id-ul nu poate fi editat
						textField_1.setText(rs.getString(2));
						textField_2.setText(rs.getString(3));
						textField_3.setText(rs.getString(4));
						textField_4.setEditable(false); // Gender nu poate fi editat
						textField_4.setText(rs.getString(5));
						textField_5.setText(rs.getString(6));
						textField_6.setText(rs.getString(7));
						textField_7.setEditable(false); // Timpul nu poate fi editat
						textField_7.setText(rs.getString(8));
						textField_8.setText(rs.getString(9));
						textField_9.setText(rs.getString(10));
						
					}
					
				if(check == 0) JOptionPane.showMessageDialog(null,"Member ID does not exist");
				
				}catch(Exception t) {
			     JOptionPane.showMessageDialog(null,t);
				}
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1.setIcon(new ImageIcon(UpdateDeleteMember.class.getResource("/Images/search.png")));
		btnNewButton_1.setBounds(224, 135, 119, 21);
		panel.add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("Name:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(10, 201, 359, 13);
		panel.add(lblNewLabel_2);
		
		textField_1 = new JTextField();
		textField_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField_1.setBounds(10, 224, 359, 19);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Mobile Number:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_3.setBounds(10, 263, 359, 13);
		panel.add(lblNewLabel_3);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField_2.setBounds(10, 286, 359, 19);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("E-mail:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_4.setBounds(10, 331, 359, 13);
		panel.add(lblNewLabel_4);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField_3.setBounds(10, 354, 359, 19);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Gender: ");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_5.setBounds(10, 399, 359, 13);
		panel.add(lblNewLabel_5);
		
		textField_4 = new JTextField();
		textField_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField_4.setBounds(10, 422, 359, 19);
		panel.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Father Name:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_6.setBounds(10, 464, 359, 13);
		panel.add(lblNewLabel_6);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField_5.setBounds(10, 487, 359, 19);
		panel.add(textField_5);
		textField_5.setColumns(10);
		
		JButton btnNewButton_2 = new JButton("Update");
		btnNewButton_2.setHorizontalAlignment(SwingConstants.LEFT);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { // La apasarea butonului UPDATE
				//retinem valorile modificate
				String id = textField.getText();
				String nume = textField_1.getText();
				String mobilenumber = textField_2.getText();
				String email = textField_3.getText();
				String fathername = textField_5.getText();
				String mothername = textField_6.getText();
				String age = textField_8.getText();
				String amount = textField_9.getText();
				
				
				try {
					Connection c = connectionProvider.getConnection();
					PreparedStatement ps = c.prepareStatement("update membrii set nume=?,mobilenumber=?,email=?,fathername=?,mothername=?,age=?,amount=? where id=?");
					// Datele din tabel se vor reinitializa cu datele introduse in casute
					ps.setString(1,nume);
					ps.setString(2,mobilenumber);
					ps.setString(3,email);
					ps.setString(4,fathername);
					ps.setString(5,mothername);
					ps.setString(6,age);
					ps.setString(7,amount);
					ps.setString(8,id);
					ps.executeUpdate();
					JOptionPane.showMessageDialog(null,"Successfully updated!");
					setVisible(false);
					new UpdateDeleteMember().setVisible(true);
					
				}catch(Exception p) {
					JOptionPane.showMessageDialog(null,p);
				}
				
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_2.setIcon(new ImageIcon(UpdateDeleteMember.class.getResource("/Images/save.png")));
		btnNewButton_2.setBounds(10, 531, 123, 21);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Delete");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { //La apasarea butonului DELETE
				int a = JOptionPane.showConfirmDialog(null,"Do you really want to delete?","Select",JOptionPane.YES_NO_OPTION);
				if(a==0) // Daca utilizatorul a selectat YES
				{
					String id = textField.getText();
					try {
						Connection c = connectionProvider.getConnection();
						Statement st = c.createStatement();
						st.executeUpdate("delete from membrii where id='"+id+"'"); //Stergem utilizatorul din lista
						JOptionPane.showMessageDialog(null,"Successfully deleted!");
						setVisible(false);
						new UpdateDeleteMember().setVisible(true); // Afisam o noua fereastra cu campuri necompletate
					}catch(Exception r) {
						JOptionPane.showMessageDialog(null,r);
					}
				}
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_3.setIcon(new ImageIcon(UpdateDeleteMember.class.getResource("/Images/delete.png")));
		btnNewButton_3.setBounds(143, 531, 108, 21);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Reset");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
				new UpdateDeleteMember().setVisible(true);
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_4.setIcon(new ImageIcon(UpdateDeleteMember.class.getResource("/Images/reset.png")));
		btnNewButton_4.setBounds(261, 531, 108, 21);
		panel.add(btnNewButton_4);
		
		JLabel lblNewLabel_8 = new JLabel("Mother Name");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_8.setBounds(562, 201, 115, 13);
		panel.add(lblNewLabel_8);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField_6.setColumns(10);
		textField_6.setBounds(562, 224, 369, 19);
		panel.add(textField_6);
		
		JLabel lblNewLabel_9 = new JLabel("Gym Time");
		lblNewLabel_9.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_9.setBounds(562, 252, 94, 35);
		panel.add(lblNewLabel_9);
		
		JLabel lblNewLabel_10 = new JLabel("Age");
		lblNewLabel_10.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_10.setBounds(562, 325, 61, 24);
		panel.add(lblNewLabel_10);
		
		textField_8 = new JTextField();
		textField_8.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField_8.setColumns(10);
		textField_8.setBounds(562, 354, 369, 19);
		panel.add(textField_8);
		
		JLabel lblNewLabel_11 = new JLabel("Amount to pay/month");
		lblNewLabel_11.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_11.setBounds(562, 395, 174, 21);
		panel.add(lblNewLabel_11);
		
		textField_9 = new JTextField();
		textField_9.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField_9.setColumns(10);
		textField_9.setBounds(562, 422, 369, 19);
		panel.add(textField_9);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Tahoma", Font.BOLD, 14));
		textField_7.setColumns(10);
		textField_7.setBounds(562, 286, 359, 19);
		panel.add(textField_7);
	}

}
