package project;
import java.sql.*;

public class connectionProvider {
   public static Connection getConnection() {
      try {
          Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
          Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/gym?user=root&password=123456789a");
          return connection;
      }
      catch (Exception ex) {
          System.err.println("An Exception occured during JDBC Driver loading." + 
             " Details are provided below:");
          ex.printStackTrace(System.err);
          return null;
      }
      
   } 
   public static void main(String[] args) {
	   Connection connection = null;
	      Statement selectStatement = null, insertStatement = null;
	      ResultSet rs = null;
	      ResultSetMetaData rsmd = null;
	      try {
	          connection = DriverManager.
	             getConnection("jdbc:mysql://localhost/gym?user=root&password=123456789a");
	          insertStatement = connection.createStatement();
	          insertStatement.execute("INSERT INTO membrii (id, nume, mobilenumber, email, gender, fathername, mothername,gymtime, age, amount) " + 
	             "VALUES ('1','George','0040264123456','john.doe@example.com','male','Flaviu','Maria','FULL','20','100')");
	          insertStatement.execute("INSERT INTO membrii (id, nume, mobilenumber, email, gender, fathername, mothername,gymtime, age, amount) " + 
	                  "VALUES ('2','Petre','0040264123456','petre.doe@example.com','male','Dan','Ana','FULL','20','100')");
	          selectStatement = connection.createStatement();
	          selectStatement.execute("SELECT * FROM membrii");
	          rs = selectStatement.getResultSet();
	          rsmd = rs.getMetaData();
	          System.out.println("There are " + rsmd.getColumnCount() + " columns in the result set:");
	          for (int i = 1; i <= rsmd.getColumnCount(); i++)
	             System.out.println("\t Column " + (i) + " is " + rsmd.getColumnName(i));

	      }
	      catch(SQLException sqlex) {
	          System.err.println("An SQL Exception occured. Details are provided below:");
	          sqlex.printStackTrace(System.err);
	      }
	      finally {
	         if (rs != null) { 
	            try { 
	                rs.close();  
	            } 
	            catch(SQLException e) {
	            }  
	            rs = null;  
	         }
	         if (selectStatement != null) { 
	            try { 
	                selectStatement.close();  
	            } 
	            catch(SQLException e) {}  
	            selectStatement = null;  
	         }
	         if (insertStatement != null) { 
	            try { 
	                insertStatement.close();  
	            } 
	            catch(SQLException e) {}  
	            insertStatement = null;  
	         }
	         if (connection != null) { 
	            try { 
	                connection.close();  
	            } 
	            catch(SQLException e) {}  
	            connection = null;  
	         }
	      }
   }
}


